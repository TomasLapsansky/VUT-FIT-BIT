#include <stdio.h>
#include <ctype.h>
#include <string.h>

int get_word(char* s, int max, FILE *f);
