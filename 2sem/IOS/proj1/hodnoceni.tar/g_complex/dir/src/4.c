#include "header.h"
void foo_4() { printf("Doing something %d\n", 4); }
